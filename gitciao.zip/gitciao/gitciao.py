# For educational & personal use only
# Git clone multiple Git by feeding a text file containing URLs
# January 4th 2019
# Created by: Yacer Razouani

from git import Repo
import os

seed = "seed.txt"          # Insert numbers of all the teams
teams = []
with open(seed) as inputfile:
    for line in inputfile:
        teams.append(line.rstrip().split('\n'))

for team in teams:
    repo = Repo.clone_from(
        "https://githost.gi.polymtl.ca/git/log1000-" + team[0],
        './TEMPGIT/' + team[0],
        branch='master', depth=1,
        config='http.sslVerify=false',
        )
